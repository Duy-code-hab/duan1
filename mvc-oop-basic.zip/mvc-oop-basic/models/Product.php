<?php
class Product
{
    private $db;

    public function __construct($db)
    {
        $this->db = $db; // Kết nối cơ sở dữ liệu
    }

    // Lấy tất cả sản phẩm
    public function getAllProducts()
    {
        $stmt = $this->db->prepare("SELECT * FROM products");
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Thêm sản phẩm mới
    public function addProduct($data)
    {
        $sql = "INSERT INTO products (ten_san_pham, gia_san_pham, gia_khuyen_mai, hinh_anh, so_luong, ngay_nhap, mo_ta, danh_muc_id, trang_thai)
                VALUES (:ten_san_pham, :gia_san_pham, :gia_khuyen_mai, :hinh_anh, :so_luong, :ngay_nhap, :mo_ta, :danh_muc_id, :trang_thai)";
        $stmt = $this->db->prepare($sql);
        $stmt->execute($data);
        return $this->db->lastInsertId();
    }

    // Cập nhật sản phẩm
    public function updateProduct($id, $data)
    {
        $sql = "UPDATE products SET 
                ten_san_pham = :ten_san_pham,
                gia_san_pham = :gia_san_pham,
                gia_khuyen_mai = :gia_khuyen_mai,
                hinh_anh = :hinh_anh,
                so_luong = :so_luong,
                ngay_nhap = :ngay_nhap,
                mo_ta = :mo_ta,
                danh_muc_id = :danh_muc_id,
                trang_thai = :trang_thai
                WHERE id = :id";
        $stmt = $this->db->prepare($sql);
        $data['id'] = $id;
        $stmt->execute($data);
        return $stmt->rowCount();
    }

    // Xóa sản phẩm
    public function deleteProduct($id)
    {
        $stmt = $this->db->prepare("DELETE FROM products WHERE id = :id");
        $stmt->execute([':id' => $id]);
        return $stmt->rowCount();
    }
}