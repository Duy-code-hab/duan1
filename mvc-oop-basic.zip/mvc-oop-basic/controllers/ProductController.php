<?php
class ProductController
{
    private $productModel;

    public function __construct($db)
    {
        $this->productModel = new Product($db);
    }

    // Danh sách sản phẩm
    public function index()
    {
        $products = $this->productModel->getAllProducts();
        include 'views/products/index.php';
    }

    // Thêm sản phẩm
    public function create()
    {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $data = [
                ':ten_san_pham' => $_POST['ten_san_pham'],
                ':gia_san_pham' => $_POST['gia_san_pham'],
                ':gia_khuyen_mai' => $_POST['gia_khuyen_mai'],
                ':hinh_anh' => $_POST['hinh_anh'],
                ':so_luong' => $_POST['so_luong'],
                ':ngay_nhap' => $_POST['ngay_nhap'],
                ':mo_ta' => $_POST['mo_ta'],
                ':danh_muc_id' => $_POST['danh_muc_id'],
                ':trang_thai' => $_POST['trang_thai']
            ];
            $this->productModel->addProduct($data);
            header('Location: index.php?controller=Product&action=index');
        }
        include 'views/products/create.php';
    }

    // Sửa sản phẩm
    public function edit($id)
    {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $data = [
                ':ten_san_pham' => $_POST['ten_san_pham'],
                ':gia_san_pham' => $_POST['gia_san_pham'],
                ':gia_khuyen_mai' => $_POST['gia_khuyen_mai'],
                ':hinh_anh' => $_POST['hinh_anh'],
                ':so_luong' => $_POST['so_luong'],
                ':ngay_nhap' => $_POST['ngay_nhap'],
                ':mo_ta' => $_POST['mo_ta'],
                ':danh_muc_id' => $_POST['danh_muc_id'],
                ':trang_thai' => $_POST['trang_thai']
            ];
            $this->productModel->updateProduct($id, $data);
            header('Location: index.php?controller=Product&action=index');
        }
        $product = $this->productModel->getAllProducts($id);
        include 'views/products/edit.php';
    }

    // Xóa sản phẩm
    public function delete($id)
    {
        $this->productModel->deleteProduct($id);
        header('Location: index.php?controller=Product&action=index');
    }
}