<?php
class AdminBaoCaoThongKeController{
    public function home(){
        require_once './views/home.php';
    }
}


?>