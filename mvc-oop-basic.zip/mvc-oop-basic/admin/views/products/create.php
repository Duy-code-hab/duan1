<h1>Thêm sản phẩm mới</h1>
<form method="POST" action="">
    <label for="ten_san_pham">Tên sản phẩm:</label>
    <input type="text" name="ten_san_pham" required><br>

    <label for="gia_san_pham">Giá sản phẩm:</label>
    <input type="number" name="gia_san_pham" required><br>

    <label for="gia_khuyen_mai">Giá khuyến mãi:</label>
    <input type="number" name="gia_khuyen_mai"><br>

    <label for="hinh_anh">Hình ảnh (URL):</label>
    <input type="text" name="hinh_anh"><br>

    <label for="so_luong">Số lượng:</label>
    <input type="number" name="so_luong" required><br>

    <label for="ngay_nhap">Ngày nhập:</label>
    <input type="date" name="ngay_nhap" required><br>

    <label for="mo_ta">Mô tả:</label>
    <textarea name="mo_ta"></textarea><br>

    <label for="danh_muc_id">Mã danh mục:</label>
    <input type="number" name="danh_muc_id" required><br>

    <label for="trang_thai">Trạng thái:</label>
    <select name="trang_thai">
        <option value="1">Hoạt động</option>
        <option value="0">Không hoạt động</option>
    </select><br><br>

    <button type="submit">Thêm sản phẩm</button>
</form>