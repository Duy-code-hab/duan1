<h1>Danh sách sản phẩm</h1>
<table border="1" cellpadding="10">
    <thead>
        <tr>
            <th>ID</th>
            <th>Tên sản phẩm</th>
            <th>Giá sản phẩm</th>
            <th>Giá khuyến mãi</th>
            <th>Hình ảnh</th>
            <th>Số lượng</th>
            <th>Ngày nhập</th>
            <th>Hành động</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($products as $product): ?>
            <tr>
                <td><?= $product['id'] ?></td>
                <td><?= $product['ten_san_pham'] ?></td>
                <td><?= $product['gia_san_pham'] ?></td>
                <td><?= $product['gia_khuyen_mai'] ?></td>
                <td><img src="<?= $product['hinh_anh'] ?>" alt="Ảnh" width="50"></td>
                <td><?= $product['so_luong'] ?></td>
                <td><?= $product['ngay_nhap'] ?></td>
                <td>
                    <a href="index.php?controller=Product&action=edit&id=<?= $product['id'] ?>">Sửa</a>
                    |
                    <a href="index.php?controller=Product&action=delete&id=<?= $product['id'] ?>" onclick="return confirm('Bạn có chắc chắn muốn xóa sản phẩm này?')">Xóa</a>
                </td>
            </tr>
        <?php endforeach; ?>
    </tbody>
</table>
<a href="index.php?controller=Product&action=create">Thêm sản phẩm mới</a>